package com.example.mistareasitt.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ControladorDataBase extends SQLiteOpenHelper {

    private static final String DB_NAME = "db_app.db";
    private static final String DB_TABLE_USUARIOS = "USUARIOS";
    private static final String DB_TABLE_TAREAS = "TAREAS";
    private static final int DB_VERSION = 3;


    public ControladorDataBase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + DB_TABLE_USUARIOS + " (" +
                "ID_USUARIO INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "NOMBRE_USUARIO TEXT NOT NULL, " +
                "PASS TEXT NOT NULL);");

        db.execSQL("CREATE TABLE " + DB_TABLE_TAREAS + "(" +
                "ID_TAREA INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "NOMBRE_TAREA TEXT NOT NULL, " +
                "NOMBRE_USUARIO INTEGER, " +
                "FOREIGN KEY (NOMBRE_USUARIO) REFERENCES USUARIOS);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("DROP TABLE " + DB_TABLE_USUARIOS );
        db.execSQL("DROP TABLE " + DB_TABLE_TAREAS );
        onCreate(db);

    }

    public void addTarea(String tarea, String nombre) {

        ContentValues registroUsuario = new ContentValues();
        registroUsuario.put("NOMBRE_TAREA", tarea);
        registroUsuario.put("NOMBRE_USUARIO", nombre);

        //1. ABRIR LA BD

        SQLiteDatabase db = this.getWritableDatabase();

        //2. EJECUTAR ACCIÓN
        db.insert("TAREAS", null, registroUsuario);
        //db.execSQL("INSERT INTO USUARIOS VALUES ('nombre' + 'pass' );");

        //3. CERRAR LA BD
        db.close();
    }


    public String[] obtenerTareasUsuario(String usuario) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM TAREAS WHERE NOMBRE_USUARIO=?", new String[]{String.valueOf(usuario)});

        int regs = cursor.getCount();
        if (regs == 0) {
            db.close();
            return null;
        } else {
            String[] tareas = new String[regs];
            cursor.moveToFirst();
            for (int i = 0; i < regs; i++) {
                tareas[i] = cursor.getString(1);
                cursor.moveToNext();
            }
            db.close();
            return tareas;
        }
    }

    public int numeroRegistros(String nombre) {

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM TAREAS WHERE NOMBRE_USUARIO=?", new String[]{String.valueOf(nombre)});
        return cursor.getCount();
    }


    public void borrarTarea(String tarea){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("TAREAS","NOMBRE_TAREA=?", new String[]{tarea});
        db.close();

    }

    public boolean usuarioExiste(String usuario){

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM USUARIOS WHERE NOMBRE_USUARIO=?", new String[]{String.valueOf(usuario)} );

        int regs = cursor.getCount();
        if (regs == 0) {
            db.close();
            return false;
        } else {
            db.close();
            return true;

        }

    }

    public void addUsuario(String nombre, String pass ) {

        ContentValues registroUsuario = new ContentValues();
        registroUsuario.put("NOMBRE_USUARIO", nombre);
        registroUsuario.put("PASS", pass);


        SQLiteDatabase db = this.getWritableDatabase();


        db.insert("USUARIOS", null, registroUsuario);


        db.close();
    }


}
