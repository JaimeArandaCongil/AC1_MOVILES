package com.example.mistareasitt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mistareasitt.db.ControladorDataBase;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    ControladorDataBase controladorDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        controladorDB = new ControladorDataBase(LoginActivity.this);

        getSupportActionBar().hide();
    }


    public void login(View view){

        TextInputEditText usuario = findViewById(R.id.cajaUsuarioL);
        TextInputEditText pass = findViewById(R.id.cajaPassL);

        if(controladorDB.usuarioExiste(usuario.getText().toString())){
            Intent intent = new Intent(this, MainActivity.class);
            EditText nombreUsuario = findViewById(R.id.cajaUsuarioL);
            intent.putExtra("usuario", nombreUsuario.getText().toString());
            Toast toast = Toast.makeText(this, "Login correcto", Toast.LENGTH_LONG);
            toast.show();
            startActivity(intent);
        }else{
            Toast toast = Toast.makeText(this, "Credenciales Inválidas", Toast.LENGTH_LONG);
            toast.show();
        }

    }

    public void registerActivity(View view){

        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);

    }
}