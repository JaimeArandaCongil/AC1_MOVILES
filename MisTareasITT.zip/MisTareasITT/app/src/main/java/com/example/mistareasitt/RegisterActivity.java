package com.example.mistareasitt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mistareasitt.db.ControladorDataBase;
import com.google.android.material.textfield.TextInputEditText;

public class RegisterActivity extends AppCompatActivity {

    ControladorDataBase controladorDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        controladorDB = new ControladorDataBase(RegisterActivity.this);

        getSupportActionBar().hide();
    }


    public void comprobarExiste(View view){

        TextInputEditText usuario = findViewById(R.id.cajaUsuarioC);
        TextInputEditText pass = findViewById(R.id.cajaPassC);

        if(controladorDB.usuarioExiste(usuario.getText().toString())){

            Toast toast = Toast.makeText(this, "Usuario en uso", Toast.LENGTH_LONG);
            toast.show();

        }else{
            controladorDB.addUsuario(usuario.getText().toString(), pass.getText().toString());

            Intent intent = new Intent(this, MainActivity.class);
            EditText nombreUsuario = findViewById(R.id.cajaUsuarioC);
            intent.putExtra("usuario", nombreUsuario.getText().toString());
            Toast toast = Toast.makeText(this, "Usuario creado", Toast.LENGTH_LONG);
            toast.show();
            startActivity(intent);
        }

    }
}